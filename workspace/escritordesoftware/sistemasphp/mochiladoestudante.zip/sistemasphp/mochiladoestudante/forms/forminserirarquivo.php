
<form action="inserirarquivo.php" method="post">
	<fieldset>
		<legend>
			Formulário para adicionar arquivo
		</legend>
								
						
		<label for="descricao">descricao:</label>
				
		<input type="text" name="descricao" id="descricao" />
						
		<label for="titulo">titulo:</label>
				
		<input type="text" name="titulo" id="titulo" />
						
		<label for="datadeenvio">datadeenvio:</label>
				
		<input type="text" name="datadeenvio" id="datadeenvio" />
						
		<label for="nomedoarquivo">nomedoarquivo:</label>
				
		<input type="text" name="nomedoarquivo" id="nomedoarquivo" />
		
		<input type="submit" value="Cadastrar">
		
	</fieldset>
</form>