
<form action="inserirusuario.php" method="post">
	<fieldset>
		<legend>
			Formulário para adicionar usuario
		</legend>
								
						
		<label for="nom">nom:</label>
				
		<input type="text" name="nom" id="nom" />
						
		<label for="email">email:</label>
				
		<input type="text" name="email" id="email" />
						
		<label for="nomedeusuario">nomedeusuario:</label>
				
		<input type="text" name="nomedeusuario" id="nomedeusuario" />
						
		<label for="senha">senha:</label>
				
		<input type="text" name="senha" id="senha" />
						
		<label for="instituicao">instituicao:</label>
				
		<input type="text" name="instituicao" id="instituicao" />
						
		<label for="niveldeacesso">niveldeacesso:</label>
				
		<input type="text" name="niveldeacesso" id="niveldeacesso" />
						
		<label for="foto">foto:</label>
				
		<input type="text" name="foto" id="foto" />
		
		<input type="submit" value="Cadastrar">
		
	</fieldset>
</form>