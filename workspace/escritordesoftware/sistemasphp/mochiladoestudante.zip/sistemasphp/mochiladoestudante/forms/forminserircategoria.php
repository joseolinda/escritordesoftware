
<form action="inserircategoria.php" method="post">
	<fieldset>
		<legend>
			Formulário para adicionar categoria
		</legend>
								
						
		<label for="id">id:</label>
				
		<input type="text" name="id" id="id" />
						
		<label for="nome">nome:</label>
				
		<input type="text" name="nome" id="nome" />
						
		<label for="descricao">descricao:</label>
				
		<input type="text" name="descricao" id="descricao" />
		
		<input type="submit" value="Cadastrar">
		
	</fieldset>
</form>