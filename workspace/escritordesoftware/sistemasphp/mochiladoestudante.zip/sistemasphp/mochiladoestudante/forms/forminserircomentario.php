
<form action="inserircomentario.php" method="post">
	<fieldset>
		<legend>
			Formulário para adicionar comentario
		</legend>
								
						
		<label for="id">id:</label>
				
		<input type="text" name="id" id="id" />
						
		<label for="texto">texto:</label>
				
		<input type="text" name="texto" id="texto" />
						
		<label for="data">data:</label>
				
		<input type="text" name="data" id="data" />
						
		<label for="hora">hora:</label>
				
		<input type="text" name="hora" id="hora" />
		
		<input type="submit" value="Cadastrar">
		
	</fieldset>
</form>