
<form action="inserirforum.php" method="post">
	<fieldset>
		<legend>
			Formulário para adicionar forum
		</legend>
								
						
		<label for="titulo">titulo:</label>
				
		<input type="text" name="titulo" id="titulo" />
						
		<label for="corpo">corpo:</label>
				
		<input type="text" name="corpo" id="corpo" />
		
		<input type="submit" value="Cadastrar">
		
	</fieldset>
</form>