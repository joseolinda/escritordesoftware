
<form action="inserirusuario.php" method="post">
	<fieldset>
		<legend>
			Formulário para adicionar usuario
		</legend>
								
						
		<label for="nome">nome:</label>
				
		<input type="text" name="nome" id="nome" />
						
		<label for="email">email:</label>
				
		<input type="text" name="email" id="email" />
						
		<label for="login">login:</label>
				
		<input type="text" name="login" id="login" />
						
		<label for="senha">senha:</label>
				
		<input type="text" name="senha" id="senha" />
						
		<label for="nivel">nivel:</label>
				
		<input type="text" name="nivel" id="nivel" />
						
		<label for="datadecadastro">datadecadastro:</label>
				
		<input type="text" name="datadecadastro" id="datadecadastro" />
						
		<label for="horadecadastro">horadecadastro:</label>
				
		<input type="text" name="horadecadastro" id="horadecadastro" />
		
		<input type="submit" value="Cadastrar">
		
	</fieldset>
</form>