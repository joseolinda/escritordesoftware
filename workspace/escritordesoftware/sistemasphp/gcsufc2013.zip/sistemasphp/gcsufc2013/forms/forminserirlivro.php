
<form action="inserirlivro.php" method="post">
	<fieldset>
		<legend>
			Formulário para adicionar livro
		</legend>
								
						
		<label for="titulo">titulo:</label>
				
		<input type="text" name="titulo" id="titulo" />
						
		<label for="autor">autor:</label>
				
		<input type="text" name="autor" id="autor" />
						
		<label for="data">data:</label>
				
		<input type="text" name="data" id="data" />
						
		<label for="hora">hora:</label>
				
		<input type="text" name="hora" id="hora" />
						
		<label for="descricao">descricao:</label>
				
		<input type="text" name="descricao" id="descricao" />
						
		<label for="link0">link0:</label>
				
		<input type="text" name="link0" id="link0" />
						
		<label for="link1">link1:</label>
				
		<input type="text" name="link1" id="link1" />
						
		<label for="link2">link2:</label>
				
		<input type="text" name="link2" id="link2" />
						
		<label for="visibilidade">visibilidade:</label>
				
		<input type="text" name="visibilidade" id="visibilidade" />
						
		<label for="caminhofoto">caminhofoto:</label>
				
		<input type="text" name="caminhofoto" id="caminhofoto" />
		
		<input type="submit" value="Cadastrar">
		
	</fieldset>
</form>