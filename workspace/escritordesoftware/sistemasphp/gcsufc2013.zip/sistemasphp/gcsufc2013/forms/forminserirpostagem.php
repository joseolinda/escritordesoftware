
<form action="inserirpostagem.php" method="post">
	<fieldset>
		<legend>
			Formulário para adicionar postagem
		</legend>
								
						
		<label for="titulo">titulo:</label>
				
		<input type="text" name="titulo" id="titulo" />
						
		<label for="corpo">corpo:</label>
				
		<input type="text" name="corpo" id="corpo" />
						
		<label for="data">data:</label>
				
		<input type="text" name="data" id="data" />
						
		<label for="caminhofoto">caminhofoto:</label>
				
		<input type="text" name="caminhofoto" id="caminhofoto" />
						
		<label for="hora">hora:</label>
				
		<input type="text" name="hora" id="hora" />
		
		<input type="submit" value="Cadastrar">
		
	</fieldset>
</form>