
<form action="inserirusuario.php" method="post">
	<fieldset>
		<legend>
			Formulário para adicionar usuario
		</legend>
								
						
		<label for="nome">nome:</label>
				
		<input type="text" name="nome" id="nome" />
						
		<label for="login">login:</label>
				
		<input type="text" name="login" id="login" />
						
		<label for="senha">senha:</label>
				
		<input type="text" name="senha" id="senha" />
		
		<input type="submit" value="Cadastrar">
		
	</fieldset>
</form>