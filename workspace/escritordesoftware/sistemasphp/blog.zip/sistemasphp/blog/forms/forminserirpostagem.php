
<form action="inserirpostagem.php" method="post">
	<fieldset>
		<legend>
			Formulário para adicionar postagem
		</legend>
								
						
		<label for="Titulo">Titulo:</label>
				
		<input type="text" name="Titulo" id="Titulo" />
						
		<label for="Corpo">Corpo:</label>
				
		<input type="text" name="Corpo" id="Corpo" />
						
		<label for="juyguygufuguyguyy5678">juyguygufuguyguyy5678:</label>
				
		<input type="text" name="juyguygufuguyguyy5678" id="juyguygufuguyguyy5678" />
		
		<input type="submit" value="Cadastrar">
		
	</fieldset>
</form>